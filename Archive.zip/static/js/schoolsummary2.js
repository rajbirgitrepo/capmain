Highcharts.setOptions({
    colors: ['#67BCE6'],
    chart: {
       zoomType: 'x',
      style: {
        fontFamily: 'sans-serif',
        color: '#fff'
      }
    }
  }); 
    var settings = {
        "async": true,
        "crossDomain": true,
        "url":             "https://testcapxp.innerexplorer.org/progschoolcount",
        "method": "GET"
       }
        $.ajax(settings).done(function (response) {
        var dataa=JSON.parse(response); 
        console.log(dataa,"hello frnd")
  $('#container').highcharts({
    chart: {
      type: 'column',
      backgroundColor: '#FFFFF'
    },
    title: {
      text: 'Program Wise School Count',
      style: {  
       color: '#000000'
      }
    },
    xAxis: {
      tickWidth: 0,
      labels: {
       style: {
         color: '#000000',
         }
       },
      categories: dataa.progname
    },
    yAxis: {
      title: {
        text: 'SCHOOL COUNT',
        style: {
         color: '#000000'
         }
      },
      labels: {
        formatter: function() {
          return Highcharts.numberFormat(this.value, 0, '', ',');
        },
        style: {
          color: '#000000',
        }
      }
    },
    legend: {
      enabled: false,
    },
    credits: {
      enabled: false
    },
    tooltip: {
      valuePrefix: ''
    },
    plotOptions: {
      series: {point: {
                events: {
                    click: function () {
                        $('#next').empty();
                        console.log(URL);
                        $('#btnExport').show();
                        
                      
                     URL = 'https://testcapxp.innerexplorer.org//schoolsummaryprog/'+this.category ;
          console.log(URL);               
          createDynamic(URL)
          ok();
                    }
                }
            }}
    },
    series: [{
        color: '#01a451',
      name: 'SCHOOL COUNT',
      data: dataa.schoolcount
    }]
  });
        });


        Highcharts.setOptions({
            colors: ['#67BCE6'],
            chart: {
               zoomType: 'x',
              style: {
                fontFamily: 'sans-serif',
                color: '#fff'
              }
            }
          }); 
            var settings = {
                "async": true,
                "crossDomain": true,
                "url":             "https://testcapxp.innerexplorer.org/planschoolcount",
                "method": "GET"
               }
                $.ajax(settings).done(function (response) {
                var dataa=JSON.parse(response); 
                console.log(dataa,"hello frnd")
          $('#container2').highcharts({
            chart: {
              type: 'column',
              backgroundColor: '#FFFFF'
            },
            title: {
              text: 'Plan Wise School Count',
              style: {  
               color: '#000000'
              }
            },
            xAxis: {
              tickWidth: 0,
              labels: {
               style: {
                 color: '#000000',
                 }
               },
              categories: [dataa.progname[2],dataa.progname[0],dataa.progname[1],dataa.progname[3]]
            },
            yAxis: {
              title: {
                text: 'SCHOOL COUNT',
                style: {
                 color: '#000000'
                 }
              },
              labels: {
                formatter: function() {
                  return Highcharts.numberFormat(this.value, 0, '', ',');
                },
                style: {
                  color: '#000000',
                }
              }
            },
            legend: {
              enabled: false,
            },
            credits: {
              enabled: false
            },
            tooltip: {
              valuePrefix: ''
            },
            plotOptions: {
              series: {point: {
                        events: {
                            click: function () {
                                $('#next').empty();
                                console.log(URL);
                                $('#btnExport').show();
                             URL = 'https://testcapxp.innerexplorer.org/schoolsummaryplan/'+this.category ;
                  console.log(URL);               
                  createDynamic(URL)
                  ok();
                            }
                        }
                    }}
            },
            series: [{
                color: '#01a451',
              name: 'SCHOOL COUNT',
              data: [dataa.schoolcount[2],dataa.schoolcount[0],dataa.schoolcount[1],dataa.schoolcount[3]]
            }]
          });
                });

                function createDynamic(url){

                    var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": url,
                    "method": "GET"
                    }
                    $.ajax(settings).done(function (response) {
                    var data1=JSON.parse(response);
                    
                    $('#next').prepend('<table class="table table-striped custab table-fixed" id = "dataTable" ><thead ><tr><tr><th>SCHOOL NAME</th><th>ADMIN NAME</th><th>ADMIN EMAIL</th><th>CITY</th><th>STATE</th><th>COUNTRY</th><th>SUBSCRIPTION EXPIRY</th><th>LAST PRACTICE</th><th>PRACTICE COUNT</th></tr></thead ><tbody>');
                                          
                    for(var i=0;i<data1.data.length;i++){
                    
                    
                    var datain = data1.data[i];
                    var resultDiv = createDynamicDiv(datain);
                    
                    $("#dataTable").append(resultDiv);
                    
                    
                    
                    
                    }
                    //$('#dataTable1').append('</tbody></table>');
                    $('#dataTable').append('</tbody></table>');
                    dataTab();
                    
                    
                    
                    $('#next1').prepend('<table class="table table-striped custab table-fixed" style="display:none;" id = "dataTable1" ><thead ><tr><tr><th>SCHOOL NAME</th><th>ADMIN NAME</th><th>ADMIN EMAIL</th><th>CITY</th><th>STATE</th><th>COUNTRY</th><th>SUBSCRIPTION EXPIRY</th><th>LAST PRACTICE</th><th>PRACTICE COUNT</th></tr></thead ><tbody>');
                    for(var i=0;i<data1.data.length;i++){
                    
                    
                    var datain = data1.data[i];
                    
                    var resultDiv = createDynamicDiv(datain);
                    $("#dataTable1").append(resultDiv);
                    
                    }
                    $('#dataTable1').append('</tbody></table>');
                    })
                    }
                    function dataTab()
                    {
                    
                    $("#dataTable").DataTable( {
                        "pageLength": 50
                    } );
                    
                    }
                    function createDynamicDiv(userList){
                    var dynamicDiv = '';
                        console.log(userList)
                        
                    
                    
                      
                      
                      dynamicDiv +=   '<tr >'+
                                '<td>'+userList[0]+'</td>'+
                                '<td><a href="familycard?'+userList[1]+'">'+userList[1]+'</td></a>'+	  	
                              '<td>'+userList[2]+'</td>'+
                              '<td>'+userList[3]+'</td>'+
                                '<td>'+userList[4]+'</td>'+
                              '<td>'+userList[5]+'</td>'+
                              '<td>'+userList[6]+'</td>'+
                              '<td>'+userList[7]+'</td>'+
                              '<td>'+userList[8]+'</td>'+
                             
                              '</tr>'
                    
                            
                        return dynamicDiv;
                        
                    }
                    function ok() {
                      var elmnt = document.getElementById("next");
                      elmnt.scrollHeight();
                    }