var settings = {
  async: true,
  crossDomain: true,
  url: "https://testcapxp.innerexplorer.org/modetype",
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var dataa = JSON.parse(response);
  console.log("this is total");
  const total =
    dataa.amount.Payment_Mode_Amount[0] +
    dataa.amount.Payment_Mode_Amount[1] +
    dataa.amount.Payment_Mode_Amount[2] +
    dataa.amount.Payment_Mode_Amount[3] +
    dataa.amount.Payment_Mode_Amount[4] +
    dataa.amount.Payment_Mode_Amount[5] +
    dataa.amount.Payment_Mode_Amount[6] +
    dataa.amount.Payment_Mode_Amount[7] +
    dataa.amount.Payment_Mode_Amount[8] +
    dataa.amount.Payment_Mode_Amount[9] +
    dataa.amount.Payment_Mode_Amount[10] +
    dataa.amount.Payment_Mode_Amount[11];

    
  console.log(total + "this is total");
  $("#Total_amount").text("$ " + parseFloat(total).toFixed(1));

  console.log(dataa.amount.Payment_Mode[1] + "this is mode");
  console.log(dataa.amount.Payment_Mode_Amount[0] + "this is amojnt");
  $("#t1").text("$ " + dataa.amount.Payment_Mode[0]);
  $("#t2").text("$ " + dataa.amount.Payment_Mode[1]);
  $("#t3").text("$ " + dataa.amount.Payment_Mode[2]);
  $("#t4").text("$ " + dataa.amount.Payment_Mode[3]);
  $("#t5").text("$ " + dataa.amount.Payment_Mode[4]);
  $("#t6").text("$ " + dataa.amount.Payment_Mode[5]);
  $("#t7").text("$ " + dataa.amount.Payment_Mode[6]);
  $("#t8").text("$ " + dataa.amount.Payment_Mode[7]);
  $("#PAYLATER").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[0]).toFixed(1)
  );
  $("#PROMOCODE").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[1]).toFixed(1)
  );
  $("#SQUARE_PAYMENT").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[2]).toFixed(1)
  );
  $("#PAYPAL").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[3]).toFixed(1)
  );
  $("#INVITED_USER").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[4]).toFixed(1)
  );
  $("#GRANT").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[5]).toFixed(1)
  );
  $("#APPLE").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[6]).toFixed(1)
  );
  $("#CHEQUE").text(
    "$ " + parseFloat(dataa.amount.Payment_Mode_Amount[7]).toFixed(1)
  );
});
