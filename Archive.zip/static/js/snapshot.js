$('#capsnap').text('Based on data captured yesterday.');



      