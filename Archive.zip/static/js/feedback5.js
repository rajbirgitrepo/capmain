$(function () {
    Highcharts.setOptions({
        chart: {
            style:{
                    fontFamily:'Arial, Helvetica, sans-serif', 
                    fontSize: '1em',
                    color:'#f00'
                }
        }
    });
        $('#container9').highcharts({
            chart: {
                type: 'column'
            },
            colors: [
               '#01a451',
              '#ea3838'
              
               
               
            ],
            title: {
                text: ' SENTIMENT ANALYSIS',
                style: {
                  color: '#555'
                }
            },
            legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',
                borderWidth: 0,
                backgroundColor: '#FFFFFF'
            },
            xAxis: {
                categories: [
                    '5 STAR',
                  '4 STAR',
                  '3 STAR',
                  '2 STAR',
                  '1 STAR'
                    
                ]
            },
            yAxis: {
        allowDecimals: false,
        title: {
            text: ' SENTIMENT %'
          
        }
              
    },
            tooltip: {
                shared: false,
                valueSuffix: '%'
            },
            credits: {
                enabled: false
            },
            plotOptions: {
                areaspline: {
                    fillOpacity: 0.1
                },
            series: {
                groupPadding: .15
            }
            },
            series: [{
                name: 'POSITIVE SENTIMENT',
                data: [90,77,66,60,40]
            }, {
                name: 'NEGATIVE SENTIMENT',
                data: [10,23,34,40,60]
            }]
           
        });
    });
 

//]]> 
 

//]]> 