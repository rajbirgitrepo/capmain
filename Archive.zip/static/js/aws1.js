var settings = {
  "async": true,
  "crossDomain": true,
  "url":             "https://awsdynamic.herokuapp.com/aws",
  "method": "GET"
 }
  $.ajax(settings).done(function (response) {
  var dataa=JSON.parse(response);
    console.log(dataa);
   

var chart = Highcharts.stockChart('container9', {
chart: {
  type: 'column'
},

title: {
  text: 'Feature Release'
},
yAxis: [
      {min:0, allowDecimals: false, title:{text:"COUNT"},opposite: false
      }]
  ,
  xAxis: {
    minRange: 1
  },

navigator: {
  series:{color:'#00FF00',
                  animation: {
                      duration: 0,
                  }    
  },
  xAxis: {
    minRange: 1
  }
},
plotOptions: {
    series: {point: {
              events: {
                  click: function () {
                    
                   $('#next').empty();
                   $('#btnExport').show();
                    
                   URL = 'https://awsdynamic.herokuapp.com/AWSTABLE/'+new Date(this.x ).toLocaleString('sv-SE', { day:'numeric',month:'numeric', year:'numeric', hour12:false } );
        
                   
       

        
         console.log(URL);
            createDynamic(URL)
              
   }
              }
          }}
  },

series: [{
  color: '#01a451',
  name: 'Releases',
  data: 
    dataa.releases.AWS_FEATURES
  , //Fri, 14 Jul 2017 00:00:00 GMT
  dataGrouping: {
    enabled: false,
  }
}]

});
      });
      function createDynamic(url){

        var settings = {
        "async": true,
        "crossDomain": true,
        "url": url,
        "method": "GET"
        }
        $.ajax(settings).done(function (response) {
        var data1=JSON.parse(response);
        
        $('#next').prepend('<table class="table table-striped custab table-fixed" id = "dataTable" ><thead ><tr><th>Date</th><th>Releases</th><th>Version</th></tr></thead ><tbody>');
                              
        for(var i=0;i<data1.data.length;i++){
        
        
        var datain = data1.data[i];
        var resultDiv = createDynamicDiv(datain);
        
        $("#dataTable").append(resultDiv);
        
        
        
        
        }
        //$('#dataTable1').append('</tbody></table>');
        $('#dataTable').append('</tbody></table>');
        dataTab();
        
        
        
         $('#next1').prepend('<table class="table table-striped custab table-fixed" style="display:none;" id = "dataTable" ><thead ><tr><th>Date</th><th>Releases</th><th>Version</th></tr></thead ><tbody>');
        for(var i=0;i<data1.data.length;i++){
        
        
        var datain = data1.data[i];
        
        var resultDiv = createDynamicDiv(datain);
        $("#dataTable1").append(resultDiv);
        
        }
        $('#dataTable1').append('</tbody></table>');
        })
        }
        function dataTab()
        {
        
        $("#dataTable").DataTable( {
            "pageLength": 50
        } );
        
        }
        function createDynamicDiv(userList){
            var dynamicDiv = '';
            console.log(userList)
            
            
            
                
                
                dynamicDiv +=   '<tr >'+
                                '<td>'+userList[0]+'</td>'+
                                '<td>'+userList[1]+'</td>'+		    	
                                '<td>'+userList[2]+'</td>'+
                           
                                '</tr>'
            
                          
            return dynamicDiv;
            
        }

        var settings = {
          "async": true,
          "crossDomain": true,
          "url":             "https://awsdynamic.herokuapp.com/aws",
          "method": "GET"
         }
          $.ajax(settings).done(function (response) {
          var dataa=JSON.parse(response);
            console.log(dataa);
        
        chart = new Highcharts.StockChart({
        
        chart: {
          renderTo: 'container99',
          zoomType: 'x'
        },
        title: {
          text: 'AWS COST VS USERGROWTH'
        },
        subtitle: {
          text: ''
        },
        
        xAxis: [{
          type: 'datetime',
          events: {
            afterSetExtremes() {
              let bottomAxis = this,
                topAxis = this.chart.xAxis[1];
              topAxis.setExtremes(bottomAxis.min - 86400000, bottomAxis.max - 86400000, true)
            }
          }
        }, {
          type: 'datetime',
          opposite: true,
          visible:false
        }],
        
        yAxis:[ {
          visible: true,
          opposite: false,
          showLastLabel: true,
           title: {
                  text: 'User Count'
              },
          labels: {
            enabled: true,
            format: "{value}",
            align: "right"
          },
        } ,{
          visible: true,
          opposite: false,
          showLastLabel: true,
          opposite:true, title: {
                  text: 'Cost'
              },
          labels: {
            enabled: true,
            format: "{value}",
            align: "left"
          },
        }],
        
        tooltip: {
          pointFormatter: function() {
            return '<span style="color:' + this.series.color + '">' + this.series.name + '</span>: <b>' + Highcharts.numberFormat(this.y, 2);
          }
        },
        
        legend: {
          enabled: true
        },
        
        navigator: {
          enabled: true
        },
        rangeSelector: {inputEnabled:false,
          enabled: true
        },
        
        scrollbar: {
          enabled: true
        },
        
        navigation: {
          buttonOptions: {
            enabled: true
          }
        },plotOptions: { column: {
            stacking: 'normal'
            
          },
          series: {
            marker: {
              enabled: false
            }
          }
        },
        
        series: [ {
          "name": "Cost",
          "type": "line",
          "color":"#FF9933",
          "xAxis": 0,
          "data": dataa.growth.Cost,yAxis: 1
        }, {
          "name": "Family",
          "type": "column",
          "xAxis": 1,
          "color":"#8AE02B",
          "data": dataa.growth.Family_Users
        }, {
          "name": "School",
          "type": "column",
          "xAxis": 1,
          "color":"#01A451",
          "data": dataa.growth.School_Users
        }]
        });
        });
        
        var settings = {
          "async": true,
          "crossDomain": true,
          "url":             "https://awsdynamic.herokuapp.com/aws",
          "method": "GET"
         }
          $.ajax(settings).done(function (response) {
          var dataa=JSON.parse(response);
            console.log(dataa);
        
        chart = new Highcharts.StockChart({
        
        chart: {
          renderTo: 'container4',
          zoomType: 'x'
        },
        title: {
          text: 'AWS COST VS PLAYBACK'
        },
        subtitle: {
          text: ''
        },
        
        xAxis: [{
          type: 'datetime',
          events: {
            afterSetExtremes() {
              let bottomAxis = this,
                topAxis = this.chart.xAxis[1];
              topAxis.setExtremes(bottomAxis.min - 86400000, bottomAxis.max - 86400000, true)
            }
          }
        }, {
          type: 'datetime',
          opposite: true,
          visible:false
        }],
        
        yAxis:[ {
          visible: true,
          opposite: false,
          showLastLabel: true,
           title: {
                  text: 'Playback Count'
              },
          labels: {
            enabled: true,
            format: "{value}",
            align: "right"
          },
        } ,{
          visible: true,
          opposite: false,
          showLastLabel: true,
          opposite:true, title: {
                  text: 'Cost'
              },
          labels: {
            enabled: true,
            format: "{value}",
            align: "left"
          },
        }],
        
        tooltip: {
          pointFormatter: function() {
            return '<span style="color:' + this.series.color + '">' + this.series.name + '</span>: <b>' + Highcharts.numberFormat(this.y, 2);
          }
        },
        
        legend: {
          enabled: true
        },
        
        navigator: {
          enabled: true
        },
        rangeSelector: {inputEnabled:false,
          enabled: true
        },
        
        scrollbar: {
          enabled: true
        },
        
        navigation: {
          buttonOptions: {
            enabled: true
          }
        },plotOptions: { column: {
            stacking: 'normal'
            
          },
          series: {
            marker: {
              enabled: false
            }
          }
        },
        
        series: [ {
          "name": "Cost",
          "type": "line",
          "color":"#FF9933",
          "xAxis": 0,
          "data": dataa.playback.cost_per_playback,yAxis: 1
        }, {
          "name": "Family",
          "type": "column",
          "xAxis": 1,
          "color":"#8AE02B",
          "data": dataa.playback.Family_Playback
        }, {
          "name": "Users",
          "type": "column",
          "xAxis": 1,
          "color":"#01A451",
          "data": dataa.playback.Users_Playback
        }]
        });
        });
        
