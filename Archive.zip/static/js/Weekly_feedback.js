

var settings = {
    "async": true,
    "crossDomain": true,
    "url":             "https://testcapxp.innerexplorer.org/highhratingweeklyP&T",
    "method": "GET"
   }
    $.ajax(settings).done(function (response) {
    var dataa=JSON.parse(response); 
     console.log(dataa,"hello frnd")
Highcharts.chart('container4', {
  chart: {
      
    type: 'column'
  },
  title: {
    text: 'Weekly FEEDBACK High Star Rating'
    },

    colors: [
        '#8AE02B','#01A451'    
                 ],

                 xAxis: {
                  categories:dataa.weekdata.day,
                  crosshair: true
                },
  
  yAxis: {
    min: 0,
    title: {
      text: 'Number of Feedbacks'
    }
  },
  tooltip: {
    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
      '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
    footerFormat: '</table>',
    shared: true,
    useHTML: true
  },
  plotOptions: {
    column: {
      stacking: 'normal',
    }
  },
  series: [{
    name: 'TEACHER RATING 5 LAST WEEK',
    data: dataa.weekdata.TEACHERrating_5LASTWEEK,
    stack: 0
  }, {
    name: 'TEACHER RATING 5 LAST TO LAST WEEK',
    data: dataa.weekdata.TEACHERrating_5LAST_TO_LAST_WEEK,
    stack: 0
  },{
    name: 'PARENT RATING 5 LAST WEEK',
    data: dataa.weekdata.PARENTrating_5LASTWEEK,
    stack: 1
  }, {
    name: 'PARENT RATING 5 LAST TO LAST WEEK',
    data:dataa.weekdata.PARENTrating_5LAST_TO_LAST_WEEK,
    stack: 1
  },{
    name: 'TECHER RATING 4 LAST WEEK',
    data: dataa.weekdata.TEACHERrating_4LASTWEEK,
    stack: 2
  }, {
    name: 'TECHER RATING 4 LAST TO LAST WEEK',
    data: dataa.weekdata.TEACHERrating_4LAST_TO_LAST_WEEK,
    stack: 2
  },
          {
    name: 'PARENT RATING 4 LAST WEEK',
    data: dataa.weekdata.PARENTrating_4LASTWEEK,
    stack: 3
  }, {
    name: 'PARENT RATING 4 LAST TO LAST WEEK',
    data: dataa.weekdata.PARENTrating_4LAST_TO_LAST_WEEK,
    stack: 3
  },{
    name: 'TECHER RATING 3 LAST WEEK',
    data: dataa.weekdata.TEACHERrating_3LASTWEEK,
    stack: 4
  }, {
    name: 'TECHER RATING 3 LAST TO LAST WEEK',
    data: dataa.weekdata.TEACHERrating_3LAST_TO_LAST_WEEK,
    stack: 4
  },
          {
    name: 'PARENT RATING 3 LAST WEEK',
    data: dataa.weekdata.PARENTrating_3LASTWEEK,
    stack: 5
  }, {
    name: 'PARENT RATING 3 LAST TO LAST WEEK',
    data: dataa.weekdata.PARENTrating_3LAST_TO_LAST_WEEK,
    stack: 5
  }]
});

    });

    var settings = {
        "async": true,
        "crossDomain": true,
        "url":             "https://testcapxp.innerexplorer.org/lowwwratingweeklyP&T",
        "method": "GET"
       }
        $.ajax(settings).done(function (response) {
        var dataa=JSON.parse(response); 
         console.log(dataa,"hello frnd")
    Highcharts.chart('container3', {
      chart: {
          
        type: 'column'
      },
      title: {
        text: 'Weekly Feedback Low star Rating'
        },
        colors: [
            '#8AE02B','#01A451'    
                     ],
                     xAxis: {
                      categories:dataa.weekdata.day,
                      crosshair: true
                    },
      yAxis: {
        min: 0,
        title: {
          text: 'Number of Feedbacks'
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          stacking: 'normal',
        }
      },
      series: [{
        name: 'TEACHER RATING 1 LAST WEEK',
        data: dataa.weekdata.TEACHERrating_1LASTWEEK,
        stack: 0
      }, {
        name: 'TEACHER RATING 1 LAST TO LAST WEEK',
        data: dataa.weekdata.TEACHERrating_1LAST_TO_LAST_WEEK,
        stack: 0
      },{
        name: 'PARENT RATING 1 LAST WEEK',
        data: dataa.weekdata.PARENTrating_1LASTWEEK,
        stack: 1
      }, {
        name: 'PARENT RATING 1 LAST TO LAST WEEK',
        data:dataa.weekdata.PARENTrating_1LAST_TO_LAST_WEEK,
        stack: 1
      },{
        name: 'TECHER RATING 2 LAST WEEK',
        data: dataa.weekdata.TEACHERrating_1LASTWEEK,
        stack: 2
      }, {
        name: 'TECHER RATING 2 LAST TO LAST WEEK',
        data: dataa.weekdata.TEACHERrating_1LAST_TO_LAST_WEEK,
        stack: 2
      },
              {
        name: 'PARENT RATING 2 LAST WEEK',
        data: dataa.weekdata.PARENTrating_1LASTWEEK,
        stack: 3
      }, {
        name: 'PARENT RATING 2 LAST TO LAST WEEK',
        data: dataa.weekdata.PARENTrating_1LAST_TO_LAST_WEEK,
        stack: 3
      }]
    });
    
        });