$("#Cap4gSnapshot").text("Based on data captured Yesterday");
var settings = {
  async: true,
  crossDomain: true,
  url: "https://testcapxp.innerexplorer.org/_executive_dashbaord_",
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var dataa = JSON.parse(response);
  console.log("counts are fnctioning");

  // $("#power").text(dataa.r4_count);
  // $("#active").text(dataa.r4_lifetime);
  // $("#passive").text(dataa.green_app);
  // $("#dormant").text(dataa.family_app);
  $("#yearmindful").text("12");

  $("#usercount").text(dataa.user_count);
  $("#totalclassroom").text(dataa.total_classrooms);
  $("#totalstudent").text(dataa.total_students);
  $("#mindful").text(dataa.mindful_minutes);
  $("#neverlogged").text(dataa.never_logged_in);
  $("#activeschools").text(dataa.active_school);
});

var settings = {
  async: true,
  crossDomain: true,
  url: "https://testcapxp.innerexplorer.org/executivecount_productwise",
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var dataa = JSON.parse(response);
  console.log("counts are fnctioning");
  $("#schoolcount").text(dataa.totalschool);
  $("#trial").text(dataa.community);
  $("#lsy").text(dataa.clound);
  $("#next6").text(dataa.explorer);


  // $("#after6").text(dataa.active_r3 + dataa.district_r3);
  // $("#power").text(dataa.r4_count);
  $("#active").text(dataa.lifetime);
  $("#passive").text(dataa.schoolapp);
  $("#dormant").text(dataa.homeapp);


  // $("#usercount").text(dataa.user_count);
  // $("#totalclassroom").text(dataa.total_classrooms);
  // $("#totalstudent").text(dataa.total_students);
  // $("#mindful").text(dataa.mindful_minutes);
  // $("#neverlogged").text(dataa.never_logged_in);
  // $("#activeschools").text(dataa.active_school);
});
//new

