var e = document.getElementById("logid").textContent;
console.log(e);
function idbased()
{
    var i = parseInt(e, 15);
    console.log(i);
  if(i<=7){
    console.log("hello2")

    // $("#userbase").append('<i class="fa fa-home"  aria-hidden="true"></i><a href="#">EXECUTIVE SUMMARY</a><ul class="side-nav-dropdown"><li class="active"><a href="Executive_Dashboard">EXECUTIVE DASHBOARD</a></li><li class="active"><a href="Parents_Analytics">HOME APP OVERVIEW</a></li><li class="active"><a href="Weekly_Analytics">WEEKLY ANALYTICS</a></li><li class="active"><a href="Daily_Analytics">DAILY ANALYTICS</a></li><li class="active"><a href="aws_releases">COMPASS RELEASES</a></li></ul>');
    $("#trans").append('<i class="fa fa-dollar"></i><a href="#">Subscription and Revenue</a><ul class="side-nav-dropdown"><li><a href="Upcoming_Renewals">Upcoming Renewal</a></li><li><a href="Sms_analytics">SMS Analytics</a></li><li><a href="Bill_later">Bill me Later</a></li><li><a href="aws">AWS Analytics</a></li></ul>');

}
  else{
    console.log("h2i")
    // $("#userbase").append('<i class="fa fa-home "  aria-hidden="true"></i><a href="#">EXECUTIVE SUMMARY</a><ul class="side-nav-dropdown"><li><a href="Parents_Analytics">HOME APP OVERVIEW</a></li><li><a href="Weekly_Analytics">WEEKLY ANALYTICS</a></li><li><a href="Daily_Analytics">DAILY ANALYTICS</a></li><li><a href="aws_releases">COMPASS RELEASES</a></li></ul>');
    $("#trans").append('<i class="fa fa-dollar"></i><a href="#">Subscription and Revenue</a><ul class="side-nav-dropdown"><li><a href="Upcoming_Renewals">Upcoming Renewal</a></li><li><a href="Sms_analytics">SMS Analytics</a></li><li><a href="Bill_later">Bill me Later</a></li><li><a href="aws">AWS Analytics</a></li></ul>');

}
}
function executiveurl(){
    var i = parseInt(e, 15);
    if(i<=7){
        console.log("hello user")
    }
    else{
        window.location.href = "School_Analytics";
    }
}