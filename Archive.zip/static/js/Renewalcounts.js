P();
P2();
ut = "https://testcapxp.innerexplorer.org/upcomingtable";
ud = "https://testcapxp.innerexplorer.org/upcomingzeropractable";
uo = "https://testcapxp.innerexplorer.org/upcomingonbtable";

//expired current school year
rt = "https://testcapxp.innerexplorer.org/cloudtable";
rd = "https://testcapxp.innerexplorer.org/cloudpractice";
ro = "https://testcapxp.innerexplorer.org/cloudonboard";

//trial
tt = "https://testcapxp.innerexplorer.org/trialtable";
td = "https://testcapxp.innerexplorer.org/trialzeropracticetable";
to = "https://testcapxp.innerexplorer.org/trialtableonbording";

//after current school year
at = "https://testcapxp.innerexplorer.org/aftercsytable";
ad = "https://testcapxp.innerexplorer.org/aftercsytableozeroprac";
ao = "https://testcapxp.innerexplorer.org/aftercsytableoonbording";

ct = "https://testcapxp.innerexplorer.org/expcsytable";
cd = "https://testcapxp.innerexplorer.org/expcsytabledatazeropractice";
co = " https://testcapxp.innerexplorer.org/expcsytableonboarding";

lt = "https://testcapxp.innerexplorer.org/lifetimetable";
ld = "https://testcapxp.innerexplorer.org/lifetimezeropracticetable";
lo = "https://testcapxp.innerexplorer.org/lifetimetableonbording";

function P2() {
  var settings = {
    async: true,
    crossDomain: true,
    url: "https://testcapxp.innerexplorer.org/dashcount",
    method: "GET",
  };
  $.ajax(settings).done(function (response) {
    var dataa = JSON.parse(response);

    $("#usercount").text(dataa.totaluserbase[0]);
  });
}

function P() {
  var settings = {
    async: true,
    crossDomain: true,
    url: "https://testcapxp.innerexplorer.org/renewalcardnew",
    method: "GET",
  };
  $.ajax(settings).done(function (response) {
    var dataa = JSON.parse(response);
    console.log(dataa.totalschool);

    $("#schoolcount").text("3881");
    console.log(dataa.trial.onboarding);
    $("#trial").text(dataa.trial.total);
    $("#trialonboarding").text(dataa.trial.onbording);
    $("#trialdormant").text(dataa.trial.zeropractice);
    $("#trialpractice").text(dataa.trial.practising);

    $("#lsy").text(dataa.cloud.total);
    $("#lsyonboarding").text(dataa.cloud.onbording);
    $("#lsydormant").text(dataa.cloud.zeropractice);
    $("#lsypractice").text(dataa.cloud.practising);

    $("#last6").text(dataa.expcsy.total);
    $("#recentonboarding").text(dataa.expcsy.onbording);
    $("#recentdormant").text(dataa.expcsy.zeropractice);
    $("#recentpractice").text(dataa.expcsy.practising);

    $("#next6").text(dataa.upccsy.total);
    $("#upcomingonboarding").text(dataa.upccsy.onbording);
    $("#upcomingdormant").text(dataa.upccsy.zeropractice);
    $("#upcomingpractice").text(dataa.upccsy.practising);

    $("#after6").text(dataa.aftercsy.total);
    $("#afteronboarding").text(dataa.aftercsy.onbording);
    $("#afterdormant").text(dataa.aftercsy.zeropractice);
    $("#afterpractice").text(dataa.aftercsy.practising);

    $("#lifetime").text(dataa.lifetime.total);
    $("#lifeonboarding").text(dataa.lifetime.onbording);
    $("#lifedormant").text(dataa.lifetime.zeropractice);
    $("#lifepractice").text(dataa.lifetime.practising);
  });
}
function TT() {
  $("#next").empty();
  $("#container").empty();
  console.log(tt);
  ok();
  $("#btnExport").show();
  $("#tablename").text("TRAIL TOTAL");
  createDynamic(tt);
}
function TO() {
  $("#next").empty();
  $("#container").empty();
  console.log(to);
  ok();
  $("#btnExport").show();
  $("#tablename").text("TRAIL ONBOARDING");
  createDynamic(to);
}
function TD() {
  $("#next").empty();
  $("#container").empty();
  console.log(td);
  ok();
  $("#btnExport").show();
  $("#tablename").text("TRIAL DORAMNT");
  createDynamic(td);
}
function RT() {
  $("#next").empty();
  $("#container").empty();
  console.log(rt);
  ok();
  $("#btnExport").show();
  $("#tablename").text("RECENT EXPIRATION TOTAL");
  createDynamic(rt);
}
function RO() {
  $("#next").empty();
  $("#container").empty();
  console.log(ro);
  ok();
  $("#btnExport").show();
  $("#tablename").text("RECENT EXPIRATION ONBOARDING");
  createDynamic(ro);
}
function RD() {
  $("#next").empty();
  $("#container").empty();
  console.log(rd);
  ok();
  $("#btnExport").show();
  $("#tablename").text("RECENT EXPIRE DORMANT");
  createDynamic(rd);
}
function UT() {
  $("#next").empty();
  $("#container").empty();
  console.log(ut);
  ok();
  $("#btnExport").show();
  $("#tablename").text("UPCOMING RENEWAL TOTAL");
  createDynamic(ut);
}
function UO() {
  $("#next").empty();
  $("#container").empty();
  console.log(uo);
  ok();
  $("#btnExport").show();
  $("#tablename").text("UPCOMING RENEWAL ONBOARDING");
  createDynamic(uo);
}
function UD() {
  $("#next").empty();
  $("#container").empty();
  console.log(ud);
  ok();
  $("#btnExport").show();
  $("#tablename").text("UPCOMING RENEWAL DORMANT");
  createDynamic(ud);
}
function AT() {
  $("#next").empty();
  $("#container").empty();
  console.log(at);
  ok();
  $("#btnExport").show();
  $("#tablename").text("AFTER CSY TOTAL");
  createDynamic(at);
}
function AO() {
  $("#next").empty();
  $("#container").empty();
  console.log(ao);
  ok();
  $("#btnExport").show();
  $("#tablename").text("AFTER CSY ONBOARDING");
  createDynamic(ao);
}
function AD() {
  $("#next").empty();
  $("#container").empty();
  console.log(ad);
  ok();
  $("#btnExport").show();
  $("#tablename").text("AFTER CSY DORMANT");
  createDynamic(ad);
}
function CT() {
  $("#next").empty();
  $("#container").empty();
  console.log(ct);
  ok();
  $("#btnExport").show();
  $("#tablename").text("EXPIRATION CSY TOTAL");
  createDynamic(ct);
}
function CO() {
  $("#next").empty();
  $("#container").empty();
  console.log(co);
  ok();
  $("#btnExport").show();
  $("#tablename").text("EXPIRATION CSY ONBOARDING");
  createDynamic(co);
}
function CD() {
  $("#next").empty();
  $("#container").empty();
  console.log(cd);
  ok();
  $("#btnExport").show();
  $("#tablename").text("EXPIRATION CSY DORMANT");
  createDynamic(cd);
}
function LT() {
  $("#next").empty();
  $("#container").empty();
  console.log(lt);
  ok();
  $("#btnExport").show();
  $("#tablename").text("LIFETIME TOTAL");
  createDynamic(lt);
}
function LO() {
  $("#next").empty();
  $("#container").empty();
  console.log(lo);
  ok();
  $("#btnExport").show();
  $("#tablename").text("LIFETIME ONBOARDING");
  createDynamic(lo);
}
function LD() {
  $("#next").empty();
  $("#container").empty();
  console.log(ld);
  ok();
  $("#btnExport").show();
  $("#tablename").text("LIFETIME DORMANT");
  createDynamic(ld);
}
function createDynamic(url) {
  var settings = {
    async: true,
    crossDomain: true,
    url: url,
    method: "GET",
  };
  $.ajax(settings).done(function (response) {
    var data1 = JSON.parse(response);

    $("#next").prepend(
      '<table class="table table-striped custab table-fixed" id = "dataTable" ><thead ><tr><th>SCHOOL NAME</th><th>ADMIN NAME</th><th>ADMIN EMAIL</th><th>STATE</th><th>CITY</th><th>RENEWAL DATE</th><th>USER COUNT</th><th>PRACTICE COUNT</th><th>LAST PRACTICE DATE</th></tr></thead ><tbody>'
    );

    for (var i = 0; i < data1.data.length; i++) {
      var datain = data1.data[i];
      var resultDiv = createDynamicDiv(datain);

      $("#dataTable").append(resultDiv);
    }
    //$('#dataTable1').append('</tbody></table>');
    $("#dataTable").append("</tbody></table>");
    dataTab();

    $("#next1").prepend(
      '<table class="table table-striped custab table-fixed" style="display:none;" id = "dataTable1" ><thead ><tr><th>SCHOOL NAME</th><th>ADMIN NAME</th><th>ADMIN EMAIL</th><th>STATE</th><th>CITY</th><th>RENEWAL DATE</th><th>USER COUNT</th><th>PRACTICE COUNT</th><th>LAST PRACTICE DATE</th></tr></thead ><tbody>'
    );
    for (var i = 0; i < data1.data.length; i++) {
      var datain = data1.data[i];

      var resultDiv = createDynamicDiv(datain);
      $("#dataTable1").append(resultDiv);
    }
    $("#dataTable1").append("</tbody></table>");
  });
}
function dataTab() {
  $("#dataTable").DataTable({
    pageLength: 50,
  });
}
function createDynamicDiv(userList) {
  var dynamicDiv = "";
  console.log(userList);

  dynamicDiv +=
    "<tr >" +
    "<td>" +
    userList[0] +
    "</td>" +
    "<td>" +
    userList[1] +
    "</td>" +
    "<td>" +
    userList[2] +
    "</td>" +
    "<td>" +
    userList[3] +
    "</td>" +
    "<td>" +
    userList[4] +
    "</td>" +
    "<td>" +
    userList[5] +
    "</td>" +
    "<td>" +
    userList[6] +
    "</td>" +
    "<td>" +
    userList[7] +
    "</td>" +
    "<td>" +
    userList[8] +
    "</td>" +
    "</tr>";

  return dynamicDiv;
}
