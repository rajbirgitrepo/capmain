// // Prepare demo data
// // Data is joined to map using value of 'hc-key' property by default.
// // See API docs for 'joinBy' for more info on linking data and map.
// var settings = {
//   "async": true,
//   "crossDomain": true,
//   "url":             "https://mongospider.herokuapp.com/schoolname/5f155b8a3b6800007900da2a",
//   "method": "GET"
//  }
//   $.ajax(settings).done(function (response) {
//   var dataa=JSON.parse(response);
// var data = dataa;

// let URL = "https://capxpanalytics.innerexplorer.org/schoolsearch/";
// class Autocomplete {
// constructor({
//   rootNode,
//   inputNode,
//   resultsNode,

//   searchFn,
//   shouldAutoSelect = false,
//   onShow = () => {},
//   onHide = () => {},
// } = {}) {
//   this.rootNode = rootNode;
//   this.inputNode = inputNode;
//   this.resultsNode = resultsNode;
//   this.searchFn = searchFn;
//   this.shouldAutoSelect = shouldAutoSelect;
//   this.onShow = onShow;
//   this.onHide = onHide;
//   this.activeIndex = -1;
//   this.resultsCount = 0;
//   this.showResults = false;
//   this.hasInlineAutocomplete =
//     this.inputNode.getAttribute("aria-autocomplete") === "both";

//   // Setup events
//   document.body.addEventListener("click", this.handleDocumentClick);
//   this.inputNode.addEventListener("keyup", this.handleKeyup);
//   this.inputNode.addEventListener("keydown", this.handleKeydown);
//   this.inputNode.addEventListener("focus", this.handleFocus);
//   this.resultsNode.addEventListener("click", this.handleResultClick);
// }

// handleDocumentClick = (event) => {
//   if (
//     event.target === this.inputNode ||
//     this.rootNode.contains(event.target)
//   ) {
//     return;
//   }
//   this.hideResults();
// };

// handleKeyup = (event) => {
//   const { key } = event;

//   switch (key) {
//     case "ArrowUp":
//     case "ArrowDown":
//     case "Escape":
//     case "Enter":
//       event.preventDefault();
//       return;
//     default:
//       this.updateResults();
//   }

//   if (this.hasInlineAutocomplete) {
//     switch (key) {
//       case "Backspace":
//         return;
//       default:
//         this.autocompleteItem();
//     }
//   }
// };

// handleKeydown = (event) => {
//   const { key } = event;
//   let activeIndex = this.activeIndex;

//   if (key === "Escape") {
//     this.hideResults();
//     this.inputNode.value = "";
//     return;
//   }

//   if (this.resultsCount < 1) {
//     if (
//       this.hasInlineAutocomplete &&
//       (key === "ArrowDown" || key === "ArrowUp")
//     ) {
//       this.updateResults();
//     } else {
//       return;
//     }
//   }

//   const prevActive = this.getItemAt(activeIndex);
//   let activeItem;

//   switch (key) {
//     case "ArrowUp":
//       if (activeIndex <= 0) {
//         activeIndex = this.resultsCount - 1;
//       } else {
//         activeIndex -= 1;
//       }
//       break;
//     case "ArrowDown":
//       if (activeIndex === -1 || activeIndex >= this.resultsCount - 1) {
//         activeIndex = 0;
//       } else {
//         activeIndex += 1;
//       }
//       break;
//     case "Enter":
//       activeItem = this.getItemAt(activeIndex);
//       this.selectItem(activeItem);
//       return;
//     case "Tab":
//       this.checkSelection();
//       this.hideResults();
//       return;
//     default:
//       return;
//   }

//   event.preventDefault();
//   activeItem = this.getItemAt(activeIndex);
//   this.activeIndex = activeIndex;

//   if (prevActive) {
//     prevActive.classList.remove("selected");
//     prevActive.setAttribute("aria-selected", "false");
//   }

//   if (activeItem) {
//     this.inputNode.setAttribute(
//       "aria-activedescendant",
//       `autocomplete-result-${activeIndex}`
//     );
//     activeItem.classList.add("selected");
//     activeItem.setAttribute("aria-selected", "true");
//     if (this.hasInlineAutocomplete) {
//       this.inputNode.value = activeItem.innerText;
//     }
//   } else {
//     this.inputNode.setAttribute("aria-activedescendant", "");
//   }
// };

// handleFocus = (event) => {
//   this.updateResults();
// };

// handleResultClick = (event) => {
//   if (event.target && event.target.nodeName === "LI") {
//     this.selectItem(event.target);
//   }
// };

// getItemAt = (index) => {
//   return this.resultsNode.querySelector(`#autocomplete-result-${index}`);
// };

// selectItem = (node) => {
//   if (node) {
//     this.inputNode.value = node.innerText;
//     this.hideResults();
//   }
// };

// checkSelection = () => {
//   if (this.activeIndex < 0) {
//     return;
//   }
//   const activeItem = this.getItemAt(this.activeIndex);
//   this.selectItem(activeItem);
// };

// autocompleteItem = (event) => {
//   const autocompletedItem = this.resultsNode.querySelector(".selected");
//   const input = this.inputNode.value;
//   if (!autocompletedItem || !input) {
//     return;
//   }

//   const autocomplete = autocompletedItem.innerText;
//   if (input !== autocomplete) {
//     this.inputNode.value = autocomplete;
//     this.inputNode.setSelectionRange(input.length, autocomplete.length);
//   }
// };

// updateResults = () => {
//   const input = this.inputNode.value;
//   const results = this.searchFn(input);

//   this.hideResults();
//   if (results.length === 0) {
//     return;
//   }

//   this.resultsNode.innerHTML = results
//     .map((result, index) => {
//       const isSelected = this.shouldAutoSelect && index === 0;
//       if (isSelected) {
//         this.activeIndex = 0;
//       }
//       return `
//       <li
//         id='autocomplete-result-${index}'
//         class='autocomplete-result${isSelected ? " selected" : ""}'
//         role='option'
//         ${isSelected ? "aria-selected='true'" : ""}
//       >
//         ${result}
//       </li>
//     `;
//     })
//     .join("");

//   this.resultsNode.classList.remove("hidden");
//   this.rootNode.setAttribute("aria-expanded", true);
//   this.resultsCount = results.length;
//   this.shown = true;
//   this.onShow();
// };

// hideResults = () => {
//   this.shown = false;
//   this.activeIndex = -1;
//   this.resultsNode.innerHTML = "";
//   this.resultsNode.classList.add("hidden");
//   this.rootNode.setAttribute("aria-expanded", "false");
//   this.resultsCount = 0;
//   this.inputNode.setAttribute("aria-activedescendant", "");
//   this.onHide();
// };
// }

// const search = (input) => {
// if (input.length < 1) {
//   return [];
// }
// return data.filter((item) =>
//   item.toLowerCase().startsWith(input.toLowerCase())
// );
// };

// const autocomplete = new Autocomplete({
// rootNode: document.querySelector(".autocomplete"),
// inputNode: document.querySelector(".autocomplete-input"),
// resultsNode: document.querySelector(".autocomplete-results"),
// searchFn: search,
// shouldAutoSelect: true,
// });

// document.querySelector("form").addEventListener("submit", (event) => {
// event.preventDefault();
// const result = document.querySelector(".search-result");
// const input = document.querySelector(".autocomplete-input");
// // result.innerHTML = 'Searched for: ' + input.value
// $("#next").empty();
// URL = "https://capxpanalytics.innerexplorer.org/schoolsearch/" + input.value;

// $("#next").empty();
// $("#btnExport").show();
// console.log(URL);
// createDynamic(URL);

// ok();
// P();
// });


 


function createDynamic(url) {
var settings = {
  async: true,
  crossDomain: true,
  url: url,
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var data1 = JSON.parse(response);

  $("#next").prepend(
    '<table class="table table-striped custab table-fixed" id = "dataTable" ><thead ><tr><th>USER NAME</th><th>USER EMAIL</th><th>SIGNUP DATE</th><th>LAST PRACTICE DATE</th> <th>RENEWAL DATE</th> <th>PRACTICE COUNT</th></tr ></thead ><tbody>'
  );
  for (var i = 0; i < data1.data.length; i++) {
    var datain = data1.data[i];
    var resultDiv = createDynamicDiv(datain);

    $("#dataTable").append(resultDiv);
  }
  //$('#dataTable1').append('</tbody></table>');
  $("#dataTable").append("</tbody></table>");
  dataTab();

  $("#next1").prepend(
    '<table class="table table-striped custab table-fixed" style="display:none;" id = "dataTable1" ><thead ><tr><th>USER NAME</th><th>USER EMAIL</th><th>SIGNUP DATE</th><th>LAST PRACTICE DATE</th> <th>RENEWAL DATE</th> <th>PRACTICE COUNT</th></tr ></thead ><tbody>'
  );
  for (var i = 0; i < data1.data.length; i++) {
    var datain = data1.data[i];

    var resultDiv = createDynamicDiv(datain);
    $("#dataTable1").append(resultDiv);
  }
  $("#dataTable1").append("</tbody></table>");
});
}
function dataTab() {
$("#dataTable").DataTable({
  pageLength: 50,
});
}
function createDynamicDiv(userList) {
var dynamicDiv = "";
console.log(userList);

dynamicDiv +=
  "<tr >" +
  "<td>" +
  userList[0] +
  "</td>" +
  '<td><a href="Journey_score?' +
  userList[1] +
  '">' +
  userList[1] +
  "</td></a>" +
  "<td>" +
  userList[2] +
  "</td>" +
  "<td>" +
  userList[3] +
  "</td>" +
  "<td>" +
  userList[4] +
  "</td>" +
  "<td>" +
  userList[5] +
  "</td>" +
  "</tr>";

return dynamicDiv;
}
function ok() {
var elmnt = document.getElementById("admin");
elmnt.scrollIntoView();
}

function schoolsearch(){
var a = document.getElementById("searchinput").value;
URL = "https://testcapxp.innerexplorer.org/schoolsearch/"+a
console.log(URL)
P(URL);
createDynamic(URL);
};

function schoolsearch2(){
  var a = document.getElementById("searchinput").value;
  URL = "https://testcapxp.innerexplorer.org/journey/"+a;
  URL2 = "https://cap.innerexplorer.org/usersearch/"+a;
  console.log(URL)
  createDynamic(URL2);
  jou2(URL);
};


// $('#searchschool').change(function(){
//   if (this.value == '1') {
//     alert("heelo");
//     $("#sid").empty();
//     var settings = {
//       "async": true,
//       "crossDomain": true,
//       "url":             "https://mongospider.herokuapp.com/schoolname/5f155b8a3b6800007900da2a",
//       "method": "GET"
//      }
//       $.ajax(settings).done(function (response) {
//       var dataa=JSON.parse(response);
//       var availableTags = dataa;
//       $( "#tag" ).autocomplete({
//       source: availableTags,
//     });
//       });      
//     $("#sid").append('<button onclick=schoolsearch() id="hel">SEARCH</button>'); 
// }
// else if (this.value == '2') {
//   alert("heelobdjksabjkb");
//   $("#sid").empty();     
//   $("#sid").append('<button onclick=schoolsearch2() id="hel">SEARCH</button>'); 
// }
// })



function P(URL) {
  console.log(URL)
var settings = {
  async: true,
  crossDomain: true,
  url: URL,
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var dataa = JSON.parse(response);
  console.log(URL)
  $("#schoolname").text("SCHOOL NAME: " + dataa.school_name);
  $("#practice").text(dataa.school_practice_count);
  $("#state").text("STATE: " + dataa.state);
  $("#usercountse").text(dataa.user_count);
  $("#adress").text("ADRESS: " + dataa.address);
  $("#email").text("ADMIN EMAIL: " + dataa.admin_email);
  $("#country").text("COUNTRY: " + dataa.country);
  $("#city").text("CITY: " + dataa.city);
  $("#admin").text("ADMIN NAME: " + dataa.admin_name);
  var url1 = "https://testcapxp.innerexplorer.org/journey/"+dataa.admin_email;
  jou(url1);
});
};


function jou(url1){
var settings = {
  async: true,
  crossDomain: true,
  url: url1,
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var datain = JSON.parse(response);
  console.log(datain);

  $("#ucount").text(datain[0].user_count);
  $("#pcount").text(datain[0].school_practice_count);
  $("#mindfulness_minutes").text(datain[0].mindfulness_minutes);
  $("#ratings").text(datain[0].Star_5_Ratings_Recieved);
  $("#school").text(datain[0].school_name);
  $("#city").text(datain[0].city);
  $("#state").text(datain[0].state);
  $("#country").text(datain[0].country);
  $("#signup").text(datain[0].signup_date);
  $("#renewal").text(datain[0].renewal_date);
  $("#status").text(datain[0].sub_status);
  var practice = datain[0].practice_count;

  $("#practicecount").text(practice);
  $("#uniqueusercount").text(datain[0].unique_user);
  $("#months").text(datain[0].month);

  console.log(datain[0].city);
  console.log(datain[0].students_impacted);

  Highcharts.chart("graph1", {
    chart: {
      type: "line",
    },

    xAxis: {
      categories: (function () {
        // generate an array of random data
        var data = [];

        for (i = 0; i <= datain[0].month.length; i++) {
          data.push([datain[0].month[i]]);
        }
        return data;
      })(),
    },
    title: {
      text: "",
    },

    exporting: {
      enabled: false,
    },
    credits: { enabled: false },
    plotOptions: {
      line: {
        dataLabels: {
          enabled: true,
        },
        enableMouseTracking: true,
      },
    },
    series: [
      {
        name: "PRACTICE TREND",
        data: (function () {
          // generate an array of random data
          var data = [];

          for (i = 0; i <= datain[0].practice_count.length; i++) {
            data.push([datain[0].practice_count[i]]);
          }
          return data;
        })(),
        color: "#01a451",
      },
    ],
  });

  Highcharts.chart("graph2", {
    chart: {
      type: "column",
    },
    title: {
      text: "",
    },

    xAxis: {
      categories: (function () {
        // generate an array of random data
        var data1 = [];

        for (i = 0; i <= datain[0].month.length; i++) {
          data1.push([datain[0].month[i]]);
        }
        return data1;
      })(),
    },

    exporting: {
      enabled: false,
    },

    credits: { enabled: false },
    legend: {
      reversed: true,
    },
    plotOptions: {
      series: {
        stacking: "normal",
      },
    },
    series: [
      {
        name: "Unique User",

        data: (function () {
          // generate an array of random data
          var data = [];

          for (i = 0; i <= datain[0].month.length; i++) {
            a = 20;

            data.push([datain[0].unique_user[i]]);
          }
          return data;
        })(),
        color: "#01a451",
      },
    ],
  });
});
};

function P2(URL) {
  console.log(URL)
var settings = {
  async: true,
  crossDomain: true,
  url: URL,
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var dataa = JSON.parse(response);
  console.log(URL)
  $("#schoolname").text("SCHOOL NAME: " + dataa.school_name);
  $("#practice").text(dataa.school_practice_count);
  $("#state").text("STATE: " + dataa.state);
  $("#usercountse").text(dataa.user_count);
  $("#adress").text("ADRESS: " + dataa.address);
  $("#email").text("ADMIN EMAIL: " + dataa.admin_email);
  $("#country").text("COUNTRY: " + dataa.country);
  $("#city").text("CITY: " + dataa.city);
  $("#admin").text("ADMIN NAME: " + dataa.admin_name);
});
};


function jou2(url1){
  var settings = {
    async: true,
    crossDomain: true,
    url: url1,
    method: "GET",
  };
  $.ajax(settings).done(function (response) {
    var datain = JSON.parse(response);
    console.log(datain);
  
    $("#ucount").text(datain[0].user_count);
    $("#pcount").text(datain[0].school_practice_count);
    $("#mindfulness_minutes").text(datain[0].mindfulness_minutes);
    $("#ratings").text(datain[0].Star_5_Ratings_Recieved);
    $("#school").text(datain[0].school_name);
    $("#city").text(datain[0].city);
    $("#state").text(datain[0].state);
    $("#country").text(datain[0].country);
    $("#signup").text(datain[0].signup_date);
    $("#renewal").text(datain[0].renewal_date);
    $("#status").text(datain[0].sub_status);
    var practice = datain[0].practice_count;
  
    $("#practicecount").text(practice);
    $("#uniqueusercount").text(datain[0].unique_user);
    $("#months").text(datain[0].month);
    var url2 = "https://testcapxp.innerexplorer.org/schoolsearch/"+datain[0].school_name;
    P2(url2);
    console.log(datain[0].city);
    console.log(datain[0].students_impacted);
  
    Highcharts.chart("graph1", {
      chart: {
        type: "line",
      },
  
      xAxis: {
        categories: (function () {
          // generate an array of random data
          var data = [];
  
          for (i = 0; i <= datain[0].month.length; i++) {
            data.push([datain[0].month[i]]);
          }
          return data;
        })(),
      },
      title: {
        text: "",
      },
  
      exporting: {
        enabled: false,
      },
      credits: { enabled: false },
      plotOptions: {
        line: {
          dataLabels: {
            enabled: true,
          },
          enableMouseTracking: true,
        },
      },
      series: [
        {
          name: "PRACTICE TREND",
          data: (function () {
            // generate an array of random data
            var data = [];
  
            for (i = 0; i <= datain[0].practice_count.length; i++) {
              data.push([datain[0].practice_count[i]]);
            }
            return data;
          })(),
          color: "#01a451",
        },
      ],
    });
  
    Highcharts.chart("graph2", {
      chart: {
        type: "column",
      },
      title: {
        text: "",
      },
  
      xAxis: {
        categories: (function () {
          // generate an array of random data
          var data1 = [];
  
          for (i = 0; i <= datain[0].month.length; i++) {
            data1.push([datain[0].month[i]]);
          }
          return data1;
        })(),
      },
  
      exporting: {
        enabled: false,
      },
  
      credits: { enabled: false },
      legend: {
        reversed: true,
      },
      plotOptions: {
        series: {
          stacking: "normal",
        },
      },
      series: [
        {
          name: "Unique User",
  
          data: (function () {
            // generate an array of random data
            var data = [];
  
            for (i = 0; i <= datain[0].month.length; i++) {
              a = 20;
  
              data.push([datain[0].unique_user[i]]);
            }
            return data;
          })(),
          color: "#01a451",
        },
      ],
    });
  });
  };