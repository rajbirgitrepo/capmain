var settings = {
  async: true,
  crossDomain: true,
  url: "https://testcapxp.innerexplorer.org/modetype",
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var dataa = JSON.parse(response);
  Highcharts.chart('containerpie', {
    chart: {
      plotBackgroundColor: null,
      plotBorderWidth: null,
      plotShadow: false,
      type: 'pie'
    },
    title: {
      text: ''
    },
    tooltip: {
      pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    accessibility: {
      point: {
        valueSuffix: '%'
      }
    },
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: false,
          format: '<b>{point.name}</b>: {point.percentage:.1f} %'
        }
      }
    },
    series: [{
      name: 'Amount %',
      colorByPoint: true,
      data: [ {
        name:  dataa.amount.Payment_Mode[0],
        y: dataa.amount.Payment_Mode_Amount[0]
      }, {
        name:  dataa.amount.Payment_Mode[1],
        y: dataa.amount.Payment_Mode_Amount[1]
      }, {
        name:  dataa.amount.Payment_Mode[2],
        y: dataa.amount.Payment_Mode_Amount[2]
      }, {
        name:  dataa.amount.Payment_Mode[3],
        y: dataa.amount.Payment_Mode_Amount[3]
      }, {
        name:  dataa.amount.Payment_Mode[4],
        y: dataa.amount.Payment_Mode_Amount[4]
      }, {
        name:  dataa.amount.Payment_Mode[5],
        y: dataa.amount.Payment_Mode_Amount[5]
      }, {
        name:  dataa.amount.Payment_Mode[6],
        y: dataa.amount.Payment_Mode_Amount[6]
      }, {
        name:  dataa.amount.Payment_Mode[7],
        y: dataa.amount.Payment_Mode_Amount[7]
      },{
        name:  dataa.amount.Payment_Mode[8],
        y: dataa.amount.Payment_Mode_Amount[8]
      },{
        name:  dataa.amount.Payment_Mode[9],
        y: dataa.amount.Payment_Mode_Amount[9]
      },{
        name:  dataa.amount.Payment_Mode[10],
        y: dataa.amount.Payment_Mode_Amount[10]
      },{
        name:  dataa.amount.Payment_Mode[11],
        y: dataa.amount.Payment_Mode_Amount[11]
      },]
    }]
  });


});


