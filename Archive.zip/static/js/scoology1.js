var settings = {
    "async": true,
    "crossDomain": true,
    "url":             "https://cap4gtest.herokuapp.com/signuphistorty",
    "method": "GET"
   }
    $.ajax(settings).done(function (response) {
    var dataa=JSON.parse(response); 
   




var chart = Highcharts.stockChart('container', {
chart: {
type: 'column'
},

title: {
text: 'SIGNUP HISTORY'
},credits:{enabled:false},
xAxis: {
    minRange: 1
},
plotOptions: {
    series: {point: {
              events: {
                  click: function () {
                    
                    
           
                   $('#next').empty();
                   $('#btnExport').show();
                    
                 
                   URL = 'https://cap4gtest.herokuapp.com/signuptable/'+this.x ;
        
                   
       

        
         console.log(URL);
            createDynamic2(URL)
                  }
              }
          }}
  },

navigator: {
series:{color:'#00FF00',
                animation: {
                    duration: 0,
                }    
},
xAxis: {
    minRange: 1
},


},yAxis: [ {
    lineWidth: 1,
    opposite: false,
    title: {
        text: 'SIGNUP COUNT'
    }
},{
    lineWidth: 1,
    opposite: true,
    title: {
        text: ' CUMULATIVE COUNT'
    }
}],

series: [{
type:'column',
  color: '#01a451',
name: 'Signup Count',
data: dataa.data.signupdata, //Fri, 14 Jul 2017 00:00:00 GMT
dataGrouping: {
  enabled: false,
},

},
      {
type:'line',
  color: '#FF9933',
name: 'Total Signup Count',
data: dataa.data.signdatacum, yAxis: 1, //Fri, 14 Jul 2017 00:00:00 GMT
dataGrouping: {
  enabled: false,
},

}]

});

});
function createDynamic2(url){

    var settings = {
    "async": true,
    "crossDomain": true,
    "url": url,
    "method": "GET"
    }
    $.ajax(settings).done(function (response) {
    var data1=JSON.parse(response);
    
    $('#next').prepend('<table class="table table-striped custab table-fixed" id = "dataTable" ><thead ><tr><th>USER NAME</th><th>EMAIL</th><th>SCHOOL NAME</th><th>PRACTICE SESSIONS</th><th>COMPLETED SESSIONS</th><th>RENEWAL DATE</th><th>LAST PRACTICE DATE</th><th>MINDFUL MINUTES</th></tr></thead ><tbody>');
                          
    for(var i=0;i<data1.data.length;i++){
    
    
    var datain = data1.data[i];
    var resultDiv = createDynamic2Div(datain);
    
    $("#dataTable").append(resultDiv);
    
    
    
    
    }
    //$('#dataTable1').append('</tbody></table>');
    $('#dataTable').append('</tbody></table>');
    dataTab();
    
    
    
     $('#next1').prepend('<table class="table table-striped custab table-fixed" style="display:none;" id = "dataTable" ><thead ><tr><th>USER NAME</th><th>EMAIL</th><th>SCHOOL NAME</th><th>PRACTICE SESSIONS</th><th>COMPLETED SESSIONS</th><th>RENEWAL DATE</th><th>LAST PRACTICE DATE</th><th>MINDFUL MINUTES</th></tr></thead ><tbody>');
    for(var i=0;i<data1.data.length;i++){
    
    
    var datain = data1.data[i];
    
    var resultDiv = createDynamic2Div(datain);
    $("#dataTable1").append(resultDiv);
    
    }
    $('#dataTable1').append('</tbody></table>');
    })
    }
    function dataTab()
    {
    
    $("#dataTable").DataTable( {
        "pageLength": 50
    } );
    
    }
    function createDynamic2Div(userList){
        var dynamicDiv = '';
        console.log(userList)
        
        
        
            
            
            dynamicDiv +=   '<tr >'+
                            '<td>'+userList[0]+'</td>'+
                            '<td>'+userList[1]+'</td>'+		    	
                            '<td>'+userList[2]+'</td>'+
                            '<td>'+userList[3]+'</td>'+
                            '<td>'+userList[4]+'</td>'+
                            '<td>'+userList[5]+'</td>'+
              '<td>'+userList[6]+'</td>'+
              '<td>'+userList[7]+'</td>'+
         
                            '</tr>'
        
                      
        return dynamicDiv;
        
    }