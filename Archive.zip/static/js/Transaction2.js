var settings = {
  async: true,
  crossDomain: true,
  url: "https://testcapxp.innerexplorer.org/hpayment",
  method: "GET",
};
$.ajax(settings).done(function (response) {
  var dataa = JSON.parse(response);

  var chart = Highcharts.stockChart("container2", {
    chart: {
      type: "column",
    },

    title: {
      text: "Mobile App Payment History",
    },
    credits: false,
    xAxis: {
      minRange: 1,
    },
    plotOptions: {
      series: { point: {} },
    },

    navigator: {
      series: {
        color: "#00FF00",
        animation: {
          duration: 0,
        },
      },
      xAxis: {
        minRange: 1,
      },
    },
    yAxis: [
      {
        lineWidth: 1,
        opposite: false,
        title: {
          text: "Amount(USD)",
        },
      },
      {
        lineWidth: 1,
        opposite: true,
        title: {
          text: "Cumulative Amount(USD)",
        },
      },
    ],
    plotOptions: {
      series: {
        point: {
          events: {
            click: function () {
              $("#next").empty();
              URL =
                "https://testcapxp.innerexplorer.org/mobile/history/" +
                new Date(this.x).toLocaleString("sv-SE", {
                  day: "numeric",
                  month: "numeric",
                  year: "numeric",
                  hour12: false,
                });
              $("#btnExport").show();
              console.log(URL);
              createDynamic(URL);

              ok();
            },
          },
        },
      },
    },

    series: [
      {
        type: "column",
        color: "#01a451",
        name: "Amount",
        data: dataa.mobHistory, //Fri, 14 Jul 2017 00:00:00 GMT
        dataGrouping: {
          enabled: false,
        },
      },
      {
        type: "line",
        color: "#FF9933",
        name: "Total Amount",
        data: dataa.CummobHistory,
        yAxis: 1, //Fri, 14 Jul 2017 00:00:00 GMT
        dataGrouping: {
          enabled: false,
        },
      },
    ],
  });
});

function createDynamic(url) {
  var settings = {
    async: true,
    crossDomain: true,
    url: url,
    method: "GET",
  };
  $.ajax(settings).done(function (response) {
    var data1 = JSON.parse(response);

    $("#next").prepend(
      '<table class="table table-striped custab table-fixed" id = "dataTable" ><thead ><tr><th>USER NAME</th><th>DEVICE USED</th><th>MODE OF PAYMENT</th><th>PAYMENT DATE</th><th>AMOUNT</th></tr ></thead ><tbody>'
    );
    for (var i = 0; i < data1.data.length; i++) {
      var datain = data1.data[i];
      var resultDiv = createDynamicDiv(datain);

      $("#dataTable").append(resultDiv);
    }
    //$('#dataTable1').append('</tbody></table>');
    $("#dataTable").append("</tbody></table>");
    dataTab();

    $("#next1").prepend(
      '<table class="table table-striped custab table-fixed" id = "dataTable1" style="display:none" ><thead ><tr><th>USER NAME</th><th>DEVICE USED</th><th>MODE OF PAYMENT</th><th>PAYMENT DATE</th><th>AMOUNT</th></tr ></thead ><tbody>'
    );
    for (var i = 0; i < data1.data.length; i++) {
      var datain = data1.data[i];

      var resultDiv = createDynamicDiv(datain);
      $("#dataTable1").append(resultDiv);
    }
    $("#dataTable1").append("</tbody></table>");
  });
}
function dataTab() {
  $("#dataTable").DataTable({
    pageLength: 50,
  });
}
function createDynamicDiv(userList) {
  var dynamicDiv = "";
  console.log(userList);

  dynamicDiv +=
    "<tr >" +
    "<td>" +
    userList[0] +
    "</td>" +
    "<td>" +
    userList[1] +
    "</td>" +
    "<td>" +
    userList[2] +
    "</td>" +
    "<td>" +
    userList[3] +
    "</td>" +
    "<td>" +
    userList[4] +
    "</td>" +
    "</tr>";

  return dynamicDiv;
}
