Highcharts.chart('container2', {
    chart: {
         type: 'column'
     },
   colors: ['#00774d',
            '#81bb28',
            '#FF4500'
                
                
                
             ],
     title: {
         text: 'FAMILY SENTIMENT ANALYSIS'
     },
     xAxis: {categories:['Positive','Neutral','Negative'],
         crosshair: false
     },
     yAxis: {
       lineWidth: 1,
         min: 0,
         title: {
             text: 'Response Count'
         }
     },
   plotOptions: {
     column: {
       grouping: false,
       pointPlacement: null,
       
     },
   },
     tooltip: {
         headerFormat: '<span>{point.x}</span><br>',
         pointFormat: '<span>{series.name}</span><span{point.name}></span>: <b>{point.y}%<b>'
     },
     plotOptions: {
         series: {
             colorByPoint: true
         }
     },
    series: [{name:'Response',
         data: [57.2,29.5,13.3]
     }]
 });
 
 
 