var settings = {
    "async": true,
    "crossDomain": true,
    "url":             "https://testcapxp.innerexplorer.org/activetrendnew",
    "method": "GET"
   }
    $.ajax(settings).done(function (response) {
    var dataa=JSON.parse(response); 
      console.log(dataa[0].bar,"data")
     




Highcharts.chart('container33', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'ACTIVE USER TREND'
    },colors: [
    '#8AE02B','#01A451'
                
                
                
                
             ],
    xAxis: {
        categories: ['Aug', 'Sep', 'Oct','Nov', 'Dec','Jan', 'Feb', 'Mar', 'Apr', 'May','Jun','Jul']
    },
    yAxis: {lineWidth:1,
        min: 0,
        title: {
            text: 'User Count'
        },
        stackLabels: {
            enabled: false,
            style: {
                fontWeight: 'bold',
                color: ( // theme
                    Highcharts.defaultOptions.title.style &&
                    Highcharts.defaultOptions.title.style.color
                ) || 'gray'
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
    },
    plotOptions: {series: {point: {
             
            }},
        column: {
            stacking: 'normal',
            dataLabels: {
                enabled: false
            }
        }
    },
    series: [{
        name: 'Family Count((SY2020-2021)',
        data: dataa[1].bar2
      
    }, {
        name: 'User Count(SY2020-2021)',
        data: dataa[0].bar
    },
      {type:'spline',
       color:'#FF8300',
        name: '(SY 2019-2020)',
        data: dataa[0].curve
    }]
});});
         

var settings = {
    "async": true,
    "crossDomain": true,
    "url": "https://testcapxp.innerexplorer.org/practicehistorychart",
    "method": "GET"
  }
  $.ajax(settings).done(function (response) {
    var dataa = JSON.parse(response);
    chart = new Highcharts.StockChart({
      chart: {
        renderTo: 'containerhistory',
        zoomType: 'x'
      },
      title: {
        text: 'PRACTICE HISTORY(2018-2020)'
      },
      subtitle: {
        text: ''
      },
      xAxis: [{
        type: 'datetime', events: {
          afterSetExtremes() {
            let bottomAxis = this,
              topAxis = this.chart.xAxis[1],
              diferenciaMin = Math.abs(bottomAxis.dataMin - bottomAxis.min),
              diferenciaMax = Math.abs(bottomAxis.dataMax - bottomAxis.max);
            topAxis.setExtremes(topAxis.dataMin + diferenciaMin, topAxis.dataMax - diferenciaMax, true)
          }
        },
        labels: {
          formatter: function () {
            return Highcharts.dateFormat(' %e,%b', this.value);
          }

        }
      }, {
        type: 'datetime',
        labels: {
          formatter: function () {
            return Highcharts.dateFormat(' %e,%b', this.value);
          }

        },
        opposite: true,
        visible: false
      }],
      yAxis: {
        visible: true,
        opposite: false,
        showLastLabel: true,
        labels: {
          enabled: true,
          format: "{value}",
          align: "right"
        },
      },
      tooltip: {
        pointFormatter: function () {
          return '<span style="color:' + this.series.color + '">' + this.series.name + '</span>: <b>' + Highcharts.numberFormat(this.y, 2);
        }
      },
      legend: {
        enabled: true
      },
      navigator: {
        enabled: true
      },
      rangeSelector: {
        inputEnabled: false,
        enabled: true
      },
      scrollbar: {
        enabled: true
      },
      navigation: {
        buttonOptions: {
          enabled: true
        }
      }, plotOptions: {
        column: {
          stacking: 'normal'

        },
        series: {
          marker: {
            enabled: false
          }
        }
      },
      series: [{
        "name": "Last SY",
        "type": "line",
        "color": "#FF9933",
        "xAxis": 0,
        "data": dataa.data.lsy
      }, {
        "name": "Family",
        "type": "column",
        "color": "#8AE02B",
        "xAxis": 1,
        "data": dataa.data.pcsy
      }, {
        "name": "School",
        "type": "column",
        "xAxis": 1,
        "color": "#01A451",
        "data": dataa.data.csy
      }]
    });
  });